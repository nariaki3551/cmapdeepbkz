run "make generate_ideal"

Syntax: "./generate_ideal [--index 256] [--seed 0]"

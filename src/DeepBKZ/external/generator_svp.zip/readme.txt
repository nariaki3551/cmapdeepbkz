WARNING: can only be used to create instances of the SVP challenge (https://www.latticechallenge.org/svp-challenge/) if used with NTL 9.3 or OLDER (due to a change in the NTL pseudorandom generator)

run "make generate_random"

Syntax: "./generate_random [--dim 80] [--seed 0]"